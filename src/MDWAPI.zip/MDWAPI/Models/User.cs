namespace MDWAPI.Models;

public class User
{
    public int Id { get; set; }
    public string Username { get; set; } = string.Empty;
    public string PasswordHash { get; set; } = string.Empty;
    public string Role { get; set; } = "operator";
    public DateTime CreatedAt { get; set; }

    public bool IsActive { get; set; } = true;
}