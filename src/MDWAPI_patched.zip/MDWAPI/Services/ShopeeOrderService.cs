﻿using MDWAPI.Helpers;
using System.Text.Json;
using MDWAPI.Repos;
using Microsoft.AspNetCore.WebUtilities;

namespace MDWAPI.Services;

public class ShopeeOrderService
{
    private const string ClientName = "Shopee";

    private readonly IHttpClientFactory _http;
    private readonly IShopRepo _shopRepo;
    private readonly IPartnerRepo _partnerRepo;
    private readonly ChannelTokenResolver _resolver;
    private readonly IChannelTokenRepo _chanRepo;
    private readonly ShopeeTokenRefreshService _refresh;
    private readonly ILogger<ShopeeOrderService> _log;

    private static class ShopeeOptionalFields
    {
        // ใช้กับ get_order_detail เท่านั้น
        public const string Detail =
            "buyer_username,recipient_address,payment_method,buyer_user_id,cod," +
            "estimated_shipping_fee,days_to_ship,item_list,package_list,note," +
            "note_update_time,message_to_seller,region,reverse_shipping_fee," +
            "actual_shipping_fee_confirmed,invoice_data,order_status,pickup_done_time," +
            "pay_time,shipping_carrier,total_amount,create_time,update_time," +
            "dropshipper,dropshipper_phone,fulfillment_flag,ship_by_date,split_up,currency";
        // get_order_list: อย่าส่งฟิลด์ที่ list ไม่รองรับ (ปลอดภัยสุด: ไม่ต้องส่ง)
        public const string List = "order_status,create_time,update_time";
    }

    public ShopeeOrderService(
        IHttpClientFactory http,
        IShopRepo shopRepo,
        IPartnerRepo partnerRepo,
        ChannelTokenResolver resolver,
        IChannelTokenRepo chanRepo,
        ShopeeTokenRefreshService refresh,
        ILogger<ShopeeOrderService> log)
    {
        _http = http;
        _shopRepo = shopRepo;
        _partnerRepo = partnerRepo;
        _resolver = resolver;
        _chanRepo = chanRepo;
        _refresh = refresh;
        _log = log;
    }


    // ====== Public APIs (Raw string JSON) ======

    public async Task<string> GetShopProfileRawAsync(long shopId, CancellationToken ct = default)
    {
        var (url, http) = await BuildSignedGetAsync(
            apiPath: ShopeeApiPaths.ShopGetProfile,
            shopId: shopId,
            extraQuery: null!,
            ct: ct);

        var res = await http.GetAsync(url, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
        {
            _log.LogWarning("Shopee shop/get_profile failed: {Status} {Body}", res.StatusCode, body);
            throw new HttpRequestException($"Shopee shop/get_profile failed: {(int)res.StatusCode}");
        }
        return body;
    }

    public async Task<string> GetLogisticsChannelListRawAsync(long shopId, CancellationToken ct = default)
    {
        var (url, http) = await BuildSignedGetAsync(
            apiPath: ShopeeApiPaths.LogisticsGetChannelList,
            shopId: shopId,
            extraQuery: null!,
            ct: ct);

        var res = await http.GetAsync(url, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
        {
            _log.LogWarning("Shopee logistics/get_channel_list failed: {Status} {Body}", res.StatusCode, body);
            throw new HttpRequestException($"Shopee logistics/get_channel_list failed: {(int)res.StatusCode}");
        }
        return body;
    }

    // detail
    public async Task<string> GetOrderDetailRawAsync(long shopId, string orderSn, CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(orderSn))
            throw new ArgumentException("orderSn is required", nameof(orderSn));

        var (url, http) = await BuildSignedGetAsync(
            apiPath: ShopeeApiPaths.OrderGetDetail,
            shopId: shopId,
            extraQuery: new()
            {
                ["order_sn_list"] = orderSn,
                ["request_order_status_pending"] = "true",
                ["response_optional_fields"] = ShopeeOptionalFields.Detail
            },
            ct: ct);

        var res = await http.GetAsync(url, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
        {
            _log.LogWarning("Shopee get_order_detail failed: {Status} {Body}", res.StatusCode, body);
            throw new HttpRequestException($"Shopee get_order_detail failed: {(int)res.StatusCode}");
        }
        return body;
    }

    // list
    public async Task<string> GetOrderListRawAsync(
        long shopId,
        string timeRangeField,
        long timeFrom,
        long timeTo,
        int pageSize = 50,
        string? cursor = null,
        string? orderStatus = null,
        CancellationToken ct = default)
    {
        if (string.IsNullOrWhiteSpace(timeRangeField))
            throw new ArgumentException("timeRangeField is required", nameof(timeRangeField));

        var query = new Dictionary<string, string?>
        {
            ["time_range_field"] = timeRangeField,
            ["time_from"] = timeFrom.ToString(),
            ["time_to"] = timeTo.ToString(),
            ["page_size"] = pageSize.ToString()
            // ปลอดภัยสุด: ไม่ส่ง response_optional_fields สำหรับ list
            // ถ้าจำเป็นจริงๆ ให้ใช้เฉพาะที่รองรับ เช่น:
            // ["response_optional_fields"] = ShopeeOptionalFields.List
        };
        if (!string.IsNullOrWhiteSpace(cursor)) query["cursor"] = cursor;
        if (!string.IsNullOrWhiteSpace(orderStatus)) query["order_status"] = orderStatus;

        var (url, http) = await BuildSignedGetAsync(
            apiPath: ShopeeApiPaths.OrderGetList,
            shopId: shopId,
            extraQuery: query,
            ct: ct);

        var res = await http.GetAsync(url, ct);
        var body = await res.Content.ReadAsStringAsync(ct);
        if (!res.IsSuccessStatusCode)
        {
            _log.LogWarning("Shopee get_order_list failed: {Status} {Body}", res.StatusCode, body);
            throw new HttpRequestException($"Shopee get_order_list failed: {(int)res.StatusCode}");
        }
        return body;
    }

    
    private static ShopeeKeyMode ParseShopeeKeyMode(string? extraJson)
    {
        if (string.IsNullOrWhiteSpace(extraJson)) return ShopeeKeyMode.RawString;
        try
        {
            using var doc = JsonDocument.Parse(extraJson);
            if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                doc.RootElement.TryGetProperty("sign_mode", out var m) &&
                m.ValueKind == JsonValueKind.String &&
                Enum.TryParse<ShopeeKeyMode>(m.GetString(), ignoreCase: true, out var mode))
            {
                return mode;
            }
        }
        catch { /* ignore */ }
        return ShopeeKeyMode.RawString;
    }

    private async Task<ShopeeKeyMode> ResolveBestKeyModeAsync(string env, long partnerId, long shopId, CancellationToken ct)
    {
        // token ที่ได้จาก token/get จะบันทึก ExtraJson={"sign_mode":"..."} ไว้
        // ใช้ refresh-token row เป็นแหล่ง lookup (ไม่ต้อง valid access token)
        var row = await _chanRepo.GetLatestForRefreshAsync("shopee", env, partnerId, shopId, ct);
        row ??= await _chanRepo.GetLatestForRefreshAsync("shopee", env, partnerId: null, shopId, ct);

        return ParseShopeeKeyMode(row?.ExtraJson);
    }

    private async Task EnsureFreshTokenAsync(string env, long partnerId, long shopId, CancellationToken ct)
    {
        // ถ้า token ใกล้หมดอายุ/ไม่พบ ให้ลอง refresh ล่วงหน้า
        var check = await _chanRepo.GetCheckExpireAsync(
            channel: "shopee",
            environment: env,
            partnerId: partnerId,
            appKey: null,
            accountIdBig: shopId,
            accountIdStr: null,
            graceMinutes: 10,
            ct: ct);

        if (check == "refresh")
        {
            try
            {
                await _refresh.RefreshByShopIdAsync(shopId, ct);
            }
            catch (Exception ex)
            {
                // ไม่ throw ทันที เพื่อให้ flow ไป retry ด้วย GetAccessTokenAsync อีกครั้ง
                _log.LogWarning(ex, "Shopee token refresh preflight failed (shopId={ShopId})", shopId);
            }
        }
    }

// ====== Internal: signed URL ======

    private async Task<(string url, HttpClient http)> BuildSignedGetAsync(
        string apiPath,
        long shopId,
        Dictionary<string, string?>? extraQuery,
        CancellationToken ct)
    {
        var (partnersId, accountIdBig, _) = await _shopRepo.GetShopBindingAsync(shopId, ct);
        if (accountIdBig is null || accountIdBig.Value != shopId)
            _log.LogDebug("Shop binding accountIdBig mismatch. input={Input} bound={Bound}", shopId, accountIdBig);

        var cfg = await _partnerRepo.GetConfigByPartnersIdAsync(partnersId, ct)
                  ?? throw new InvalidOperationException($"Partners config not found: {partnersId}");
        if (cfg.PartnerId is null || string.IsNullOrWhiteSpace(cfg.PartnerKey))
            throw new InvalidOperationException("Shopee PartnerId/PartnerKey is required");

        // preflight refresh ถ้าจำเป็น
        var env = cfg.Environment ?? "prod";
        await EnsureFreshTokenAsync(env, cfg.PartnerId.Value, shopId, ct);

        string accessToken;
        string tokenEnv;

        try
        {
            var t = await _resolver.GetAccessTokenAsync(
                channel: "shopee",
                environment: env,
                partnerId: cfg.PartnerId,
                appKey: null,
                accountIdBig: shopId,
                accountIdStr: null,
                ct: ct);
            accessToken = t.accessToken;
            tokenEnv = t.environment;
        }
        catch (InvalidOperationException)
        {
            // ยังหาไม่เจอ (มักเกิดจาก access token หมดอายุ/ไม่มี valid) -> refresh แล้วลองอีกครั้ง
            await _refresh.RefreshByShopIdAsync(shopId, ct);

            var t2 = await _resolver.GetAccessTokenAsync(
                channel: "shopee",
                environment: env,
                partnerId: cfg.PartnerId,
                appKey: null,
                accountIdBig: shopId,
                accountIdStr: null,
                ct: ct);
            accessToken = t2.accessToken;
            tokenEnv = t2.environment;
        }

        var host = _resolver.HostFor("shopee", tokenEnv);
        var ts = UnixTime.NowSeconds();

        // ใช้ sign_mode ที่เคยลองสำเร็จตอน token/get
        var keyMode = await ResolveBestKeyModeAsync(env, cfg.PartnerId.Value, shopId, ct);

        var sign = ShopeeSign.BuildShopSign(
            partnerId: cfg.PartnerId.Value,
            partnerKey: cfg.PartnerKey!,
            apiPath: apiPath,
            timestamp: ts,
            accessToken: accessToken,
            shopId: shopId,
            mode: keyMode
        );

        var baseQuery = new Dictionary<string, string?>
        {
            ["partner_id"] = cfg.PartnerId.Value.ToString(),
            ["timestamp"] = ts.ToString(),
            ["sign"] = sign,
            ["access_token"] = accessToken,
            ["shop_id"] = shopId.ToString()
        };

        if (extraQuery is not null)
            foreach (var kv in extraQuery) baseQuery[kv.Key] = kv.Value;

        var url = QueryHelpers.AddQueryString($"{host}{apiPath}", baseQuery);

        var http = _http.CreateClient(ClientName);
        return (url, http);
    }
}
