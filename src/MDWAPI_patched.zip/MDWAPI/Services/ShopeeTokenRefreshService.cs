﻿using System.Text.Json;
using System.Net.Http.Json;
using System.Linq;
using Microsoft.AspNetCore.WebUtilities;
using MDWAPI.Dtos;
using MDWAPI.Helpers;
using MDWAPI.Repos;

namespace MDWAPI.Services;

public class ShopeeTokenRefreshService
{
    private const string ClientName = "Shopee";
    private readonly IHttpClientFactory _http;
    private readonly IShopRepo _shopRepo;
    private readonly IPartnerRepo _partnerRepo;
    private readonly IChannelTokenRepo _chanRepo;
    private readonly ILogger<ShopeeTokenRefreshService> _log;

    public ShopeeTokenRefreshService(
        IHttpClientFactory http,
        IShopRepo shopRepo,
        IPartnerRepo partnerRepo,
        IChannelTokenRepo chanRepo,
        ILogger<ShopeeTokenRefreshService> log)
    {
        _http = http;
        _shopRepo = shopRepo;
        _partnerRepo = partnerRepo;
        _chanRepo = chanRepo;
        _log = log;
    }

    private static string HostByEnv(string? env)
        => (env ?? "prod").Equals("sandbox", StringComparison.OrdinalIgnoreCase)
            ? "https://openplatform.sandbox.test-stable.shopee.sg"
            : "https://partner.shopeemobile.com";
    private static ShopeeKeyMode ParseShopeeKeyMode(string? extraJson)
    {
        if (string.IsNullOrWhiteSpace(extraJson)) return ShopeeKeyMode.RawString;
        try
        {
            using var doc = JsonDocument.Parse(extraJson);
            if (doc.RootElement.ValueKind == JsonValueKind.Object &&
                doc.RootElement.TryGetProperty("sign_mode", out var m) &&
                m.ValueKind == JsonValueKind.String &&
                Enum.TryParse<ShopeeKeyMode>(m.GetString(), ignoreCase: true, out var mode))
            {
                return mode;
            }
        }
        catch { /* ignore */ }
        return ShopeeKeyMode.RawString;
    }


    public async Task<object> RefreshByShopIdAsync(long shopId, CancellationToken ct = default)
    {
        // 1) map shop → partnersId/accountIdBig
        var (partnersId, accountIdBig, _) = await _shopRepo.GetShopBindingAsync(shopId, ct);
        if (accountIdBig is null)
            throw new InvalidOperationException("accountIdBig is required for Shopee refresh.");

        // 2) partner config
        var cfg = await _partnerRepo.GetConfigByPartnersIdAsync(partnersId, ct)
                  ?? throw new InvalidOperationException($"Partners config not found: {partnersId}");
        if (cfg.PartnerId is null || string.IsNullOrWhiteSpace(cfg.PartnerKey))
            throw new InvalidOperationException("Shopee PartnerId/PartnerKey is required");

        // 3) หา refresh token ล่าสุด (เฉพาะที่มี RefreshToken)
        var env = cfg.Environment ?? "prod";

        var current = await _chanRepo.GetLatestForRefreshAsync(
            channel: "shopee",
            environment: env,
            partnerId: cfg.PartnerId,
            accountIdBig: accountIdBig.Value,
            ct: ct);

        // fallback เผื่อข้อมูลเก่าเก็บ PartnerId = NULL
        current ??= await _chanRepo.GetLatestForRefreshAsync(
            channel: "shopee",
            environment: env,
            partnerId: null,
            accountIdBig: accountIdBig.Value,
            ct: ct);

        if (current is null || string.IsNullOrWhiteSpace(current.RefreshToken))
            throw new InvalidOperationException("No refresh_token found for this shop.");

        // 4) call Shopee /api/v2/auth/access_token/get
        var host = HostByEnv(env);
        var api = "/api/v2/auth/access_token/get";

        // ใช้ sign_mode เดิมก่อน ถ้าไม่มีค่อยไล่ลองทั้งหมด (กัน error_sign)
        var preferred = ParseShopeeKeyMode(current.ExtraJson);
        var modes = new List<ShopeeKeyMode> { preferred, ShopeeKeyMode.StripHexToBytes, ShopeeKeyMode.StripPrefixAscii, ShopeeKeyMode.RawString }
            .Distinct()
            .ToArray();

        var http = _http.CreateClient(ClientName);
        http.Timeout = TimeSpan.FromSeconds(30);

        var body = new
        {
            refresh_token = current.RefreshToken!,
            shop_id = accountIdBig.Value,
            partner_id = cfg.PartnerId.Value
        };

        string json = "";

        foreach (var mode in modes)
        {
            var ts = UnixTime.NowSeconds();

            var sign = ShopeeSign.BuildPartnerAuthSign(
                cfg.PartnerId.Value, cfg.PartnerKey!, api, ts, mode);

            var url = QueryHelpers.AddQueryString($"{host}{api}", new Dictionary<string, string?>
            {
                ["partner_id"] = cfg.PartnerId.Value.ToString(),
                ["timestamp"] = ts.ToString(),
                ["sign"] = sign
            });

            using var res = await http.PostAsJsonAsync(url, body, ct);
            json = await res.Content.ReadAsStringAsync(ct);

            if (res.IsSuccessStatusCode)
            {
                _log.LogInformation("Shopee access_token/get success with sign_mode={Mode}", mode);

                // parse + upsert
                using var doc = JsonDocument.Parse(json);
                var root = doc.RootElement;

                var accessTokenNew = root.GetProperty("access_token").GetString()!;
                var refreshTokenNew = root.GetProperty("refresh_token").GetString()!;
                var expireIn = root.GetProperty("expire_in").GetInt64();
                var scope = root.TryGetProperty("scope", out var sc) ? sc.GetString() : null;
                long? refreshExpIn = root.TryGetProperty("refresh_token_expire_in", out var rti) ? rti.GetInt64() : (long?)null;

                var dto = new ChannelTokenDtos
                {
                    Channel = "shopee",
                    Environment = env,
                    AuthType = "shop",
                    PartnerId = cfg.PartnerId,
                    AppKey = null,
                    AccountIdBig = accountIdBig,
                    AccountIdStr = null,
                    AccessToken = accessTokenNew,
                    RefreshToken = refreshTokenNew,
                    AccessTokenExpAt = DateTime.UtcNow.AddSeconds(expireIn),
                    RefreshTokenExpAt = refreshExpIn.HasValue ? DateTime.UtcNow.AddSeconds(refreshExpIn.Value) : null,
                    Scope = scope,
                    Country = "TH",
                    Region = "TH",
                    CompanysId = null,
                    PartnersId = cfg.Id,
                    TokenPayloadJson = json,
                    ExtraJson = $"{{\"sign_mode\":\"{mode}\"}}",
                    isActive = true
                };

                await _chanRepo.UpsertAsync(dto, ct);
                return System.Text.Json.JsonSerializer.Deserialize<object>(json)!;
            }

            if ((int)res.StatusCode == 403 && json.Contains("error_sign", StringComparison.OrdinalIgnoreCase))
            {
                _log.LogWarning("Shopee access_token/get wrong sign with mode={Mode}. Body={Body}", mode, json);
                continue;
            }

            _log.LogWarning("Shopee access_token/get failed: {Status} {Body}", res.StatusCode, json);
            throw new HttpRequestException($"Shopee access_token/get failed: {(int)res.StatusCode}. Body: {json}");
        }

        throw new HttpRequestException($"Shopee access_token/get failed: wrong sign with all key modes. LastBody: {json}");

    }
}
